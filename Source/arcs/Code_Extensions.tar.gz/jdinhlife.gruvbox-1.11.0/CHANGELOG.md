# [1.11.0](https://github.com/jdinhify/vscode-theme-gruvbox/compare/v1.10.0...v1.11.0) (2023-10-25)


### Features

* add async keyword scope in Python ([#75](https://github.com/jdinhify/vscode-theme-gruvbox/issues/75)) ([022054d](https://github.com/jdinhify/vscode-theme-gruvbox/commit/022054d0b132949768b7bb295f4f29f672fe019d))

# [1.10.0](https://github.com/jdinhify/vscode-theme-gruvbox/compare/v1.9.2...v1.10.0) (2023-10-25)


### Features

* add menu separator to match with menu border ([#74](https://github.com/jdinhify/vscode-theme-gruvbox/issues/74)) ([6c56be6](https://github.com/jdinhify/vscode-theme-gruvbox/commit/6c56be645e294218ceb32a40972d6a51c782b2e5))

## [1.9.2](https://github.com/jdinhify/vscode-theme-gruvbox/compare/v1.9.1...v1.9.2) (2023-10-25)


### Bug Fixes

* **readme:** update badges ([16b5772](https://github.com/jdinhify/vscode-theme-gruvbox/commit/16b57726a47b9d09156f906f77ddeff63d131f13))

## [1.9.1](https://github.com/jdinhify/vscode-theme-gruvbox/compare/v1.9.0...v1.9.1) (2023-10-24)


### Bug Fixes

* **readme:** update badge url ([f06827d](https://github.com/jdinhify/vscode-theme-gruvbox/commit/f06827da79ea1579f2216e6a8fe334e382d791ed))

# [1.9.0](https://github.com/jdinhify/vscode-theme-gruvbox/compare/v1.8.0...v1.9.0) (2023-10-24)


### Features

* enable semantic highlighting ([#80](https://github.com/jdinhify/vscode-theme-gruvbox/issues/80)) ([dc3310d](https://github.com/jdinhify/vscode-theme-gruvbox/commit/dc3310df19499da7a48a1210b5390d4d0b526321))

# [1.8.0](https://github.com/jdinhify/vscode-theme-gruvbox/compare/v1.7.0...v1.8.0) (2022-09-16)


### Features

* ✨ add notebook support ([#65](https://github.com/jdinhify/vscode-theme-gruvbox/issues/65)) ([83d9e73](https://github.com/jdinhify/vscode-theme-gruvbox/commit/83d9e73976c0008b5cde8bc2dca1b53e33d7073d))

# [1.7.0](https://github.com/jdinhify/vscode-theme-gruvbox/compare/v1.6.0...v1.7.0) (2022-06-06)


### Features

* ✨ add menu border colors ([#47](https://github.com/jdinhify/vscode-theme-gruvbox/issues/47)) ([d08c456](https://github.com/jdinhify/vscode-theme-gruvbox/commit/d08c456818e4d773d551750c37a39e83f717e482))

# [1.6.0](https://github.com/jdinhify/vscode-theme-gruvbox/compare/v1.5.1...v1.6.0) (2022-05-30)


### Features

* add bracket pair colors ([#54](https://github.com/jdinhify/vscode-theme-gruvbox/issues/54)) ([39744aa](https://github.com/jdinhify/vscode-theme-gruvbox/commit/39744aa09da8660898af655716b86cf9ef3d8166))

## [1.5.1](https://github.com/jdinhify/vscode-theme-gruvbox/compare/v1.5.0...v1.5.1) (2021-09-05)


### Bug Fixes

* 🐛 remove text borders in diff editor ([#42](https://github.com/jdinhify/vscode-theme-gruvbox/issues/42)) ([4e4d470](https://github.com/jdinhify/vscode-theme-gruvbox/commit/4e4d470be76ed2453638a4dc39a0268418c6593a))

# [1.5.0](https://github.com/jdinhify/vscode-theme-gruvbox/compare/v1.4.0...v1.5.0) (2021-04-29)


### Features

* ✨  add C# specific syntax highlighting ([#33](https://github.com/jdinhify/vscode-theme-gruvbox/issues/33)) ([aea4fde](https://github.com/jdinhify/vscode-theme-gruvbox/commit/aea4fded83ea9ea84b4b2d4b3f54289a9b4acc36))

## 1.4.0

-   ✨  Make input option states more visible (#23) - [Maxim Tsoy](https://github.com/muodov)

## 1.3.12

-   ✨  Add icon and improve README layout (#22) - [Michell Stuttgart](https://github.com/mstuttgart)

## 1.3.11

-   ✨  `this` highlighting for typescript

## 1.3.10

-   ✨  improvements for tab bar colors - [Layo](https://github.com/layoaster)

## 1.3.9

-   🐛  fixed tab bar background colors - [sedmicha](https://github.com/sedmicha)

## 1.3.8

-   ✨  better powershell highlighting - [michaelboulton](https://github.com/michaelboulton)

## 1.3.7

-   ✨  better support for ReasonML - [michaelboulton](https://github.com/michaelboulton)

## 1.3.6

-   📚  updated README & CHANGELOG

## 1.3.5

-   ✨  made inactive selection in Explorer tree visible - [Josh Addington](https://github.com/JoshAddington)

## 1.3.4

-   made panel.border visible

## 1.3.3

-   added activeBackground color for indent guide

## 1.3.2

-   added borders for activity bar & sidebar
-   inactive tab background color

## 1.3.1

-   used light foreground for activityBarBadge on light versions

## 1.3.0

-   now including 6 variants: Dark & Light with Medium, Hard & Soft contrast

## 1.2.0

-   added golang syntax

## 1.1.2

-   changed foreground color to use #ebdbb2 instead of fbf1c7 according to the original gruvbox

## 1.1.1

-   added minor lisp syntax - [@3ximus](https://github.com/3ximus)
-   added git colors - [@3ximus](https://github.com/3ximus)
-   made scrollbar slider background brighter for accessibility

## 1.1.0

-   more workbench colors, improvements & additional languages (c, java, python, shell) - [@3ximus](https://github.com/3ximus)

## 1.0.0

-   added workbench & terminal colors - [@3ximus](https://github.com/3ximus)

## 0.0.6

-   added line highlight color (#32302f)
-   changed caret line color to #fbf1c7
